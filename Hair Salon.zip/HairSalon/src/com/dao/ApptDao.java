package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ApptDao {

	String s="select username,password1 from Registration where username=? and password1=?";
	public boolean check(String username, String password1)
	{
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "SYSTEM", "priyanish");
		PreparedStatement ps=con.prepareStatement(s);
		ps.setString(1, username);
		ps.setString(2, password1);
		ResultSet rs  =ps.executeQuery();
		if(rs.next())
		{
return true;		}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
		return false;
	}
	
	
}
